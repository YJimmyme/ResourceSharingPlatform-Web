"""獨立訓練/保留集評估子程序，使用已保存的不可變資料快照。"""
import sys,json
from pathlib import Path
from collections import Counter
try:
    from .dataset import read_json,write_json,now
except ImportError:
    from dataset import read_json,write_json,now

def main():
    run=Path(sys.argv[1]);config=read_json(run/'config.json');snapshot=Path(config['dataset']);manifest=read_json(snapshot/'manifest.json')
    practice=config.get('practiceOnly',False)
    write_json(run/'state.json',{'status':'running','mode':config['mode'],'practiceOnly':practice,'started':now()})
    try:
        from ultralytics import YOLO
        import torch
        if config['device']=='0' and not torch.cuda.is_available():raise ValueError('目前PyTorch未啟用CUDA，請改用CPU')
        data=read_json(snapshot/'data.yaml');data['path']=str(snapshot);write_json(run/'local-data.yaml',data)
        model=YOLO(config['model'])
        if config['mode']=='train':
            def progress(trainer):write_json(run/'state.json',{'status':'running','mode':'train','practiceOnly':practice,'epoch':trainer.epoch+1,'epochs':config['epochs']})
            model.add_callback('on_train_epoch_end',progress)
            result=model.train(data=str(run/'local-data.yaml'),epochs=config['epochs'],imgsz=640,batch=2,workers=0,device=config['device'],project=str(run),name='train',exist_ok=False,seed=42,plots=True,amp=False,val=not practice)
            write_json(run/'state.json',{'status':'completed','mode':'train','practiceOnly':practice,'validationIndependent':not practice,'warning':'單張練習：無獨立驗證資料，訓練輸出的同圖分數不代表真實準確率' if practice else '', 'metrics':None if practice else {k:float(v) for k,v in result.results_dict.items()},'weights':str(run/'train/weights/best.pt'),'finished':now()})
        else:
            rows=[];correct=0;absolute_error=0;labels=set(manifest['classes'])
            for r in manifest['records']:
                if r['split']!='test':continue
                result=model.predict(str(snapshot/'images/test'/f"{r['id']}.png"),conf=config.get('confidence',.15),imgsz=640,device=config['device'],verbose=False)[0]
                predicted=Counter(result.names[int(c)] for c in result.boxes.cls.tolist());expected=Counter(x['label'] for x in r['boxes'])
                exact=predicted==expected;correct+=exact;mae=sum(abs(predicted[k]-expected[k]) for k in predicted.keys()|expected.keys());absolute_error+=mae
                rows.append({'id':r['id'],'expected':dict(expected),'predicted':dict(predicted),'exact':exact,'absoluteCountError':mae})
            if not rows:raise ValueError('沒有保留測試集')
            report={'images':len(rows),'exactItemAndCountRate':correct/len(rows),'meanAbsoluteCountErrorPerImage':absolute_error/len(rows),'confidence':config.get('confidence',.15),'rows':rows}
            write_json(run/'evaluation.json',report);write_json(run/'state.json',{'status':'completed','mode':'evaluate','evaluation':report,'finished':now()})
    except Exception as e:
        write_json(run/'state.json',{'status':'failed','error':str(e)});raise
if __name__=='__main__':main()
