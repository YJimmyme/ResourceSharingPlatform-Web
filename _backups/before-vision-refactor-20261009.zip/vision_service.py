"""Linux 正式辨識入口：Supabase認證、YOLO優先、OpenAI複核、待審回饋與模型發布。"""
import os,json,base64,uuid,math,io
from pathlib import Path
from flask import request,jsonify,g,send_file
import requests
from werkzeug.exceptions import HTTPException
from yolo_data import read_json,write_json,now
from vision_policy import canonical_boxes,fallback_reasons,grouped_items

class ServiceError(Exception):
    def __init__(self,message,status=400):super().__init__(message);self.status=status

def register(w):
    app=w.app;root=w.DATA;pending=root/'feedback';pending.mkdir(exist_ok=True)
    url=os.environ['SUPABASE_URL'].rstrip('/');anon=os.environ['SUPABASE_ANON_KEY'];service=os.environ['SUPABASE_SERVICE_ROLE_KEY']
    origin=os.environ['APP_ORIGIN'].rstrip('/');deployment=root/'deployment.json'
    threshold=float(os.environ.get('YOLO_REVIEW_THRESHOLD','.65'))
    if not math.isfinite(threshold) or not 0<threshold<1:raise ValueError('YOLO_REVIEW_THRESHOLD must be between 0 and 1')
    def rest(path,method='GET',body=None):
        r=requests.request(method,url+'/rest/v1/'+path,headers={'apikey':service,'Authorization':'Bearer '+service,'Content-Type':'application/json','Prefer':'return=representation'},json=body,timeout=30)
        if not r.ok:raise ServiceError('資料庫操作失敗，請檢查部署設定與資料表',502)
        return r.json() if r.content else None
    def auth():
        route=request.path.removeprefix('/api/v1')
        if route in ['/health','/workbench','/editor']:return
        if request.method not in ['GET','POST']:raise ServiceError('不支援的方法',405)
        if request.method=='POST' and request.headers.get('Origin')!=origin:raise ServiceError('來源不符',403)
        token=request.headers.get('Authorization','')
        if not token.startswith('Bearer '):raise ServiceError('請先登入',401)
        r=requests.get(url+'/auth/v1/user',headers={'apikey':anon,'Authorization':token},timeout=15)
        if not r.ok:raise ServiceError('登入已失效',401)
        user=r.json();rows=rest('profiles?id=eq.'+user['id']+'&select=id,role_name,location_id,is_active,display_name,username')
        if not rows or not rows[0]['is_active']:raise ServiceError('帳號未啟用',403)
        g.profile=rows[0];g.actor_id=g.profile['id']
        if route in ['/recognize','/feedback']:
            if g.profile['role_name'] not in ['Admin','Cadre']:raise ServiceError('沒有入庫權限',403)
        elif g.profile['role_name']!='Admin':raise ServiceError('限管理員操作',403)
    app.before_request_funcs.setdefault(None,[]).insert(0,auth)
    @app.errorhandler(Exception)
    def failure(e):
        status=getattr(e,'status',getattr(e,'code',400)) or 400
        if not isinstance(e,(ServiceError,ValueError,HTTPException)):app.logger.exception('vision request failed');return jsonify(success=False,error='服務處理失敗，請稍後重試',message='服務處理失敗'),500
        return jsonify(success=False,error=str(e),message=str(e)),status
    @app.after_request
    def headers(response):
        response.headers['Cache-Control']='no-store';return response
    def profile_location(location):
        if type(location)!=int or location<=0:raise ServiceError('請選據點')
        if g.profile['role_name']!='Admin' and g.profile['location_id']!=location:raise ServiceError('只能在所屬據點辨識',403)
    def feedback_record(id):
        if not isinstance(id,str) or len(id)!=32 or any(c not in '0123456789abcdef' for c in id):raise ServiceError('無效回饋ID')
        r=read_json(pending/(id+'.json'))
        if not r:raise ServiceError('找不到辨識紀錄',404)
        return r
    def openai(image,boxes,catalog,complexity):
        key=os.environ.get('OPENAI_API_KEY','')
        if not key:raise ServiceError('未設定 OpenAI API Key，請人工核對')
        model=os.environ.get('OPENAI_COMPLEX_MODEL' if complexity=='complex' else 'OPENAI_MODEL','gpt-4.1-mini')
        prompt='依整張照片的外觀，辨識所有可見獨立物件與外包裝。一箱算一箱，不推算箱內數量。不讀品牌、容量或效期。不把圖案當實物。每個實物只輸出一次，不得重複框。框必須包含完整可見物件。無法確認請填 needs_review=true 並說明 uncertainty；不得猜測不可見物品。只回傳JSON {"objects":[{"label":"品項","box":[左,上,右,下],"confidence":0.8}],"needs_review":false,"uncertainty":""}，座標為0到1。目錄只是名稱參考，外包裝不符時不得強套。\n目錄：'+json.dumps([{'name':d['item_name'],'unit':d['unit']} for d in catalog],ensure_ascii=False)+'\nYOLO初步框（可能漏判或誤判，需重新看整圖）：'+json.dumps(boxes,ensure_ascii=False)
        payload={'model':model,'messages':[{'role':'user','content':[{'type':'text','text':prompt},{'type':'image_url','image_url':{'url':image,'detail':'high'}}]}]}
        payload['max_completion_tokens' if model.startswith(('gpt-5','o1','o3','o4')) else 'max_tokens']=3000
        if not model.startswith(('gpt-5','o1','o3','o4')):payload['temperature']=.1
        r=requests.post('https://api.openai.com/v1/chat/completions',headers={'Authorization':'Bearer '+key},json=payload,timeout=120)
        if not r.ok:
            try:code=r.json().get('error',{}).get('code','unknown')
            except Exception:code='unknown'
            raise ServiceError(f'OpenAI HTTP {r.status_code} ({code})，已保留YOLO結果供人工確認')
        api=r.json();raw=api['choices'][0]['message']['content'];clean=raw.strip()
        if clean.startswith('```'):clean=clean.split('\n',1)[-1].rsplit('```',1)[0]
        parsed=json.loads(clean)
        if not isinstance(parsed.get('objects'),list) or len(parsed['objects'])>300:raise ValueError('OpenAI物件清單格式錯誤')
        return parsed,{'provider':'openai','model':api.get('model',model),'raw':raw,'usage':api.get('usage')}

    @app.post('/recognize')
    def recognize():
        b=request.json or {};location=b.get('locationId');profile_location(location)
        image_path=b.get('imagePath','')
        if not isinstance(image_path,str) or not image_path.startswith(g.profile['id']+'/') or '..' in image_path:raise ServiceError('照片必須是本人上傳檔案',403)
        r=requests.get(url+'/storage/v1/object/ai-stockin/'+requests.utils.quote(image_path,safe='/'),headers={'Authorization':'Bearer '+service,'apikey':service},timeout=30)
        if not r.ok:raise ServiceError('無法讀取照片')
        if len(r.content)>10*1024*1024:raise ServiceError('照片上限10MB')
        image='data:image/png;base64,'+base64.b64encode(r.content).decode();im,raw,image_id=w.ds.decode(image);image='data:image/png;base64,'+base64.b64encode(raw).decode()
        catalog=rest('inventory_item_definition?is_active=eq.true&select=id,category,item_name,unit,stock_type');synonyms=rest('catalog_synonym?select=synonym,standard_name')
        with w.lock:
            selected=read_json(deployment,{'model':'pretrained'})['model'];path=w.model_path(selected)
            mapping=read_json(w.DATA/'catalog-mapping.json',{})
            for d in catalog:
                w.ds.add_class(d['item_name'])
                if d.get('id') is not None and d['item_name'] not in mapping:mapping[d['item_name']]=str(d['id'])
            write_json(w.DATA/'catalog-mapping.json',mapping)
        audit={'model':selected,'imagePath':image_path,'complexity':b.get('complexity','simple')};warnings=[]
        try:
            raw_boxes=w.infer_image(im,selected,.15)
            definitions_by_id={str(d['id']):d for d in catalog if d.get('id') is not None}
            for box in raw_boxes:
                match=definitions_by_id.get(mapping.get(box['label']))
                if match:box['label']=match['item_name']
            boxes=canonical_boxes(raw_boxes,catalog,synonyms)
        except Exception:
            app.logger.exception('YOLO inference failed');boxes=[];warnings.append('YOLO執行失敗')
        audit['yolo_boxes']=boxes;reasons=fallback_reasons(boxes,catalog,threshold,b.get('forceReview') is True)
        provider='yolo';uncertain=False
        if reasons:
            try:
                cloud=im.copy();cloud.thumbnail((2048,2048));cloud_bytes=io.BytesIO();cloud.save(cloud_bytes,format='JPEG',quality=90)
                cloud_image='data:image/jpeg;base64,'+base64.b64encode(cloud_bytes.getvalue()).decode()
                parsed,provider_audit=openai(cloud_image,boxes,catalog,b.get('complexity'));new_boxes=canonical_boxes(parsed['objects'],catalog,synonyms)
                boxes=new_boxes;provider='openai';audit['openai']=provider_audit;uncertain=bool(parsed.get('needs_review'))
                unresolved=fallback_reasons(boxes,catalog,threshold)
                if unresolved:uncertain=True;warnings.extend(['複核後仍需人工確認：'+x for x in unresolved])
                if parsed.get('uncertainty'):warnings.append(str(parsed['uncertainty'])[:1000])
            except Exception as e:
                warnings.append(str(e) if isinstance(e,(ServiceError,ValueError)) else 'OpenAI複核無法完成，請人工核對');uncertain=True
        items=grouped_items(boxes);definitions={d['item_name']:d for d in catalog};id=uuid.uuid4().hex
        record={'id':id,'owner':g.profile['id'],'locationId':location,'image_id':image_id,'created':now(),'audit':audit,'boxes':boxes,'provider':provider,'reasons':reasons,'warnings':warnings,'reviewed':False}
        with w.lock:
            (pending/(id+'.png')).write_bytes(raw);write_json(pending/(id+'.json'),record)
        logs=[]
        for item in items:
            d=definitions.get(item['name'],{});logs.append({'location_id':location,'input_type':'Image','input_image_path':image_path,'input_text':b.get('inputText') or None,'suggested_category':d.get('category','其他'),'suggested_item_name':item['name'],'suggested_quantity':None if uncertain else item['quantity'],'suggested_unit':d.get('unit','個'),'suggested_stock_type':d.get('stock_type','NoExpiry'),'suggested_expiration_date':None,'suggested_remark':'外觀計數，請人工核對；回饋ID：'+id,'confidence':item['confidence'],'raw_response':json.dumps({'feedback_id':id,'provider':provider,'items':items},ensure_ascii=False),'operator':g.profile.get('display_name') or g.profile.get('username')})
        saved=rest('ai_stock_in_log','POST',logs) if logs else []
        record['log_ids']=[x['id'] for x in saved]
        with w.lock:write_json(pending/(id+'.json'),record)
        return jsonify(success=True,logs=saved,message='辨識完成，請核對品項及可見數量',feedback={'id':id,'image':image,'boxes':boxes,'provider':provider,'warnings':warnings,'reasons':reasons},requires_review=True)

    @app.post('/feedback')
    def feedback():
        b=request.json or {}
        with w.lock:
            r=feedback_record(b.get('id'));profile_location(r['locationId'])
            if g.profile['role_name']!='Admin' and r['owner']!=g.profile['id']:raise ServiceError('只能修正自己的辨識紀錄',403)
            if b.get('reviewed') is not True:raise ServiceError('請確認框選與品項已核對')
            boxes=canonical_boxes(b.get('boxes',[]),[],[])
            if not boxes and b.get('negative') is not True:raise ServiceError('空場景請明確確認')
            if any(x['label'] not in w.ds.classes() for x in boxes):raise ServiceError('請先由管理員新增目錄品項')
            history=pending/'history';history.mkdir(exist_ok=True);write_json(history/(r['id']+'-'+uuid.uuid4().hex+'.json'),r)
            r.update({'corrected_boxes':boxes,'reviewed':True,'reviewed_by':g.profile['id'],'reviewed_at':now(),'note':str(b.get('note',''))[:2000],'approved':False});write_json(pending/(r['id']+'.json'),r)
        return jsonify(success=True,message='修正已保存，等待管理員審核後納入訓練；庫存數量請在入庫表單另行核對')
    @app.get('/feedback-list')
    def feedback_list():
        rows=[read_json(p) for p in pending.glob('*.json')];return jsonify(rows=[{k:r.get(k) for k in ['id','created','reviewed','approved','provider','locationId','note']} for r in rows])
    @app.post('/approve-feedback')
    def approve_feedback():
        b=request.json or {}
        with w.lock:
            r=feedback_record(b.get('id'))
            if not r.get('reviewed'):raise ServiceError('尚未人工核對')
            if r.get('approved'):raise ServiceError('已納入資料集，請由資料清單修正')
            data={'image':'data:image/png;base64,'+base64.b64encode((pending/(r['id']+'.png')).read_bytes()).decode(),'filename':'feedback-'+r['id']+'.png','boxes':r['corrected_boxes'],'split':b.get('split','train'),'group':b.get('group') or r['image_id'],'reviewed':True,'negative':not r['corrected_boxes'],'note':r.get('note','')}
            saved=w.ds.save(data);r['approved']=True;r['approved_by']=g.profile['id'];r['dataset_id']=saved['id'];write_json(pending/(r['id']+'.json'),r)
        return jsonify(success=True)
    @app.get('/feedback-detail/<id>')
    def feedback_detail(id):
        r=feedback_record(id);return jsonify(record=r,image='data:image/png;base64,'+base64.b64encode((pending/(id+'.png')).read_bytes()).decode())
