"""Offline contract tests: no network, credentials or real training."""
import os,sys,tempfile,unittest,io,types,shutil
from pathlib import Path
from unittest.mock import patch,Mock
from PIL import Image
from yolo_data import Dataset,write_json,read_json
from vision_policy import canonical_boxes,fallback_reasons,grouped_items
_tmp=tempfile.TemporaryDirectory()
os.environ.update(VISION_PRODUCTION='1',SUPABASE_URL='https://test.invalid',SUPABASE_ANON_KEY='test-anon',SUPABASE_SERVICE_ROLE_KEY='test-service',APP_ORIGIN='http://localhost',YOLO_LAB_DATA=_tmp.name,OPENAI_API_KEY='test-key')
import yolo_worker as w
class Response:
    def __init__(self,data=None,status=200,content=b'x'):self.data=data;self.status_code=status;self.ok=status<400;self.content=content
    def json(self):return self.data
class Tests(unittest.TestCase):
    def setUp(self):
        for child in Path(_tmp.name).iterdir():
            if child.is_dir():shutil.rmtree(child)
            else:child.unlink()
        w.ds=Dataset(w.DATA);(w.DATA/'feedback').mkdir();w.active=None;w.models.clear()
        self.role='Admin';self.active=True;self.catalog=[{'item_name':'瓶裝水','category':'飲品','unit':'瓶','stock_type':'NoExpiry'}]
        self.conf=.9;self.label='瓶裝水';self.openai_calls=0;self.api_status=200
        raw=io.BytesIO();Image.new('RGB',(100,80),'white').save(raw,format='PNG');self.raw=raw.getvalue()
        self.client=w.app.test_client();self.headers={'Origin':'http://localhost','Authorization':'Bearer test-session'}
        for name,fn in [('get',self.get),('request',self.rest),('post',self.openai)]:
            p=patch('vision_service.requests.'+name,side_effect=fn);p.start();self.addCleanup(p.stop)
        p=patch.dict(sys.modules,{'ultralytics':types.SimpleNamespace(YOLO=lambda _:self)});p.start();self.addCleanup(p.stop)
    def predict(self,*args,**kwargs):
        arr=lambda value:types.SimpleNamespace(tolist=lambda:value)
        return [types.SimpleNamespace(names={0:self.label},boxes=types.SimpleNamespace(xyxyn=arr([[.1,.1,.5,.5]]),cls=arr([0]),conf=arr([self.conf])))]
    def get(self,url,**kwargs):
        if '/auth/' in url:return Response({'id':'user-1'})
        if '/storage/' in url:return Response(content=self.raw)
        raise AssertionError(url)
    def rest(self,method,url,**kwargs):
        if '/profiles?' in url:return Response([{'id':'user-1','role_name':self.role,'location_id':1,'is_active':self.active,'display_name':'Tester','username':'tester'}])
        if '/inventory_item_definition?' in url:return Response(self.catalog)
        if '/catalog_synonym?' in url:return Response([])
        if '/ai_stock_in_log' in url:return Response([dict(x,id=i+1) for i,x in enumerate(kwargs['json'])])
        raise AssertionError(url)
    def openai(self,*args,**kwargs):
        self.openai_calls+=1
        if self.api_status!=200:return Response({'error':{'code':'insufficient_quota'}},self.api_status)
        return Response({'choices':[{'message':{'content':'{"objects":[{"label":"瓶裝水","box":[0.1,0.1,0.5,0.5],"confidence":0.9}],"needs_review":false}'}}]})
    def post(self,path,body):return self.client.post(path,json=body,headers=self.headers)
    def recognize(self,**kw):return self.post('/recognize',{'locationId':1,'imagePath':'user-1/photo.png',**kw})
    def test_auth_and_scope(self):
        self.assertEqual(self.client.get('/status').status_code,401)
        self.role='Cadre';self.assertEqual(self.client.get('/status',headers=self.headers).status_code,403)
        self.assertEqual(self.recognize(locationId=2).status_code,403)
        self.assertEqual(self.recognize(imagePath='other/photo.png').status_code,403)
        self.active=False;self.assertEqual(self.recognize().status_code,403)
    def test_origin(self):
        self.headers['Origin']='http://wrong';self.assertEqual(self.recognize().status_code,403)
    def test_versioned_api_keeps_authorization(self):
        self.assertEqual(self.client.get('/api/v1/status').status_code,401)
        self.assertEqual(self.client.get('/editor').status_code,200)
        self.role='Cadre'
        self.assertEqual(self.client.get('/api/v1/module',headers=self.headers).status_code,403)
        result=self.post('/api/v1/recognize',{'locationId':1,'imagePath':'user-1/photo.png'})
        self.assertEqual(result.status_code,200,result.json)
        self.assertEqual(self.post('/api/v1/activate',{'model':'pretrained'}).status_code,403)
        self.role='Admin'
        self.assertEqual(self.client.get('/api/v1/module',headers=self.headers).status_code,200)
    def test_yolo_high_confidence_skips_cloud(self):
        r=self.recognize();self.assertEqual(r.status_code,200,r.json)
        self.assertEqual(r.json['feedback']['provider'],'yolo');self.assertEqual(self.openai_calls,0)
        self.assertEqual(r.json['logs'][0]['suggested_quantity'],1)
    def test_cloud_replaces_instead_of_adds(self):
        self.conf=.3;r=self.recognize();self.assertEqual(r.status_code,200,r.json)
        self.assertEqual(self.openai_calls,1);self.assertEqual(r.json['feedback']['provider'],'openai')
        self.assertEqual(r.json['logs'][0]['suggested_quantity'],1)
    def test_quota_retains_boxes_requires_manual_count(self):
        self.api_status=429;r=self.recognize(forceReview=True)
        self.assertEqual(r.status_code,200,r.json);self.assertEqual(len(r.json['feedback']['boxes']),1)
        self.assertIsNone(r.json['logs'][0]['suggested_quantity']);self.assertIn('429',r.json['feedback']['warnings'][0])
    def test_unknown_requests_cloud(self):
        self.label='unknown';self.recognize();self.assertEqual(self.openai_calls,1)
    def test_feedback_review_approval_and_export(self):
        r=self.recognize().json['feedback'];id=r['id']
        self.assertEqual(self.post('/approve-feedback',{'id':id}).status_code,400)
        self.assertEqual(self.post('/feedback',{'id':id,'boxes':r['boxes']}).status_code,400)
        self.assertEqual(self.post('/feedback',{'id':id,'boxes':r['boxes'],'reviewed':True}).status_code,200)
        self.assertEqual(len(w.ds.records()),0)
        self.assertEqual(self.post('/approve-feedback',{'id':id,'split':'train'}).status_code,200)
        self.assertEqual(len(w.ds.records()),1);self.assertEqual(self.post('/export',{}).status_code,200)
        self.assertEqual(self.post('/approve-feedback',{'id':id}).status_code,400)
    def test_negative_and_foreign_feedback(self):
        r=self.recognize().json['feedback'];id=r['id']
        self.assertEqual(self.post('/feedback',{'id':id,'boxes':[],'reviewed':True}).status_code,400)
        self.assertEqual(self.post('/feedback',{'id':id,'boxes':[],'reviewed':True,'negative':True}).status_code,200)
        p=w.DATA/'feedback'/(id+'.json');data=read_json(p);data['owner']='other';write_json(p,data);self.role='Cadre'
        self.assertEqual(self.post('/feedback',{'id':id,'boxes':r['boxes'],'reviewed':True}).status_code,403)
    def test_activation_requires_completed_evaluation(self):
        run=w.DATA/'runs/abc';run.mkdir();write_json(run/'state.json',{'mode':'train','status':'completed'})
        weights=run/'train/weights/best.pt';weights.parent.mkdir(parents=True);weights.touch()
        self.assertEqual(self.post('/activate',{'model':'abc'}).status_code,400)
        ev=w.DATA/'runs/eval';ev.mkdir();write_json(ev/'state.json',{'mode':'evaluate','status':'completed'});write_json(ev/'config.json',{'model':str(weights)})
        self.assertEqual(self.post('/activate',{'model':'abc'}).status_code,200)
        self.assertEqual(self.post('/activate',{'model':'pretrained'}).status_code,200)
    def test_train_creates_snapshot_and_spawns_isolated_job(self):
        w.ds.add_class('瓶裝水')
        import base64
        for color,split in [('red','train'),('blue','val'),('green','test')]:
            raw=io.BytesIO();Image.new('RGB',(100,80),color).save(raw,format='PNG')
            w.ds.save({'image':'data:image/png;base64,'+base64.b64encode(raw.getvalue()).decode(),'reviewed':True,'split':split,'boxes':[{'label':'瓶裝水','box':[.1,.1,.8,.8]}]})
        with patch('yolo_worker.subprocess.Popen',return_value=Mock(poll=Mock(return_value=None))) as spawn:
            r=self.post('/train',{'mode':'train','model':'pretrained','epochs':1,'device':'cpu'})
            self.assertEqual(r.status_code,200,r.json);spawn.assert_called_once()
            config=read_json(w.DATA/'runs'/r.json['id']/'config.json')
            self.assertTrue((Path(config['dataset'])/'manifest.json').exists());self.assertEqual(config['confidence'],.15)
            self.assertEqual(self.post('/train',{'mode':'train','model':'pretrained'}).status_code,400)
    def test_practice_requires_explicit_sample_and_cannot_publish(self):
        self.assertEqual(self.post('/train',{'mode':'train','practiceOnly':True}).status_code,400)
        import base64
        w.ds.add_class('瓶裝水')
        record=w.ds.save({'image':'data:image/png;base64,'+base64.b64encode(self.raw).decode(),'reviewed':True,'split':'train','boxes':[{'label':'瓶裝水','box':[.1,.1,.8,.8]}]})
        with patch('yolo_worker.subprocess.Popen',return_value=Mock(poll=Mock(return_value=0))):
            r=self.post('/train',{'mode':'train','model':'pretrained','practiceOnly':True,'practiceSample':record['id'],'epochs':1})
            self.assertEqual(r.status_code,200,r.json)
            run=w.DATA/'runs'/r.json['id'];self.assertTrue(read_json(run/'config.json')['practiceOnly'])
            weights=run/'train/weights/best.pt';weights.parent.mkdir(parents=True);weights.touch()
            write_json(run/'state.json',{'mode':'train','status':'completed'})
            response=self.post('/activate',{'model':r.json['id']})
            self.assertEqual(response.status_code,400);self.assertIn('單張練習',response.json['error'])
    def test_invalid_coordinates_and_grouped_counts(self):
        with self.assertRaises(ValueError):canonical_boxes([{'label':'x','box':[0,0,2,1]}],[],[])
        boxes=canonical_boxes([{'label':'bottle','box':[0,0,1,1],'confidence':.9}]*2,self.catalog,[{'synonym':'bottle','standard_name':'瓶裝水'}])
        self.assertEqual(grouped_items(boxes)[0]['quantity'],2);self.assertFalse(fallback_reasons(boxes,self.catalog,.65))
if __name__=='__main__':unittest.main()
