import _vision_bridge
from vision_module.train import main
if __name__=='__main__':main()
