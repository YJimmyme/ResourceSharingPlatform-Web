# AI 模型管理模組

這個資料夾可單獨複製使用，不需要 React、Node、Supabase 或 OpenAI 金鑰，即可執行 YOLO 標註、訓練及辨識。主系統整合透過 API，兩邊共用此處的 Python 核心與工作台。

## 在目前電腦使用

原本測試程式仍可啟動，開啟 http://127.0.0.1:5180/yolo 即為新工作台，使用原有照片、標註與模型。

若要獨立啟動：

1. 先關閉原本「啟動測試」的命令視窗。相同資料夾不能同時由兩個服務使用。
2. 雙擊本資料夾的 **啟動模組.cmd**。
3. 瀏覽器開啟 http://127.0.0.1:5182/workbench 。

在現有專案內，啟動檔會沿用 `ai-recognition-lab/yolo-data`、`models` 與已有的 Python 環境；資料不會被搬走。若把本資料夾單獨複製到其他位置，先執行 **安裝模組.cmd**，再啟動，資料會存於本資料夾的 `data`，預訓練權重存於 `models`。首次辨識／訓練需要網路下載 YOLO 權重。

## 三個操作步驟

### 1. 照片標註

新增品項 → 選擇圖片 → 將每個可見實物框起來並指定品項 → 選資料用途 → 勾選已核對 → 保存。

數量由物件框計算，例如同張照片有三瓶水，就畫三個「瓶裝水」框。不要把三瓶一起框成一個物件。資料用途：訓練用於學習、驗證用於訓練中挑選模型、保留測試用於最後評估。相同或連拍近似照片應放在相同群組，避免跨組造成評估失真。

### 2. 建立模型

只有一張照片時選 **單張練習**，選剛保存的訓練照片，輸入模型名稱並開始。正式訓練則至少需要訓練、驗證各一張有框照片；這只是啟動流程的最低要求，不能代表資料足以辨識真實場景。進階設定可選基底模型、輪數與裝置，目前電腦可使用 CPU。

等待狀態變成完成，再按「用這個模型比較」。單張練習產生的權重可供測試，但沒有獨立準確度，也不能啟用為正式入庫模型。反覆訓練同一張照片不會自動得到通用辨識能力。

### 3. 比較結果

選照片及模型 → 執行辨識。左邊顯示人工答案，右邊顯示模型預測，表格顯示各品項數量差異。比較操作不會覆寫人工標註。零個預測也會如實顯示。

正式模型應另存未參與訓練的保留測試照片，再執行保留集評估。完成評估才可按「啟用於入庫」，但系統不會替你決定準確度是否符合業務需求。可啟用先前已評估模型或通用模型回復版本。單張練習不可啟用。

## 模組邊界及未來整合

```text
主系統「AI 智慧入庫」
  → 主系統認證介面 /api/v1/recognize
  → 本模組 YOLO 核心
  → 依規則決定是否呼叫 OpenAI 複核
  → 人工確認品項、數量 → 原有入庫確認流程

主系統「AI 模型管理」管理員頁籤
  → 工作台 /workbench → 標註 → 訓練 → 比較 → 評估 → 啟用
```

獨立模組負責圖片、框、資料集快照、模型及工作進度。主系統轉接器 `ai-recognition-lab/vision_service.py` 負責 Supabase 登入、目錄、照片存取、OpenAI、入庫回饋與角色權限。獨立模式不會連線主系統或寫庫存。

「整合設定」可將類別名稱對應主系統品項 ID，`/predict` 的每個物件便會帶回 `itemId`；未對應時為 null。模型類別順序保持不變。主系統轉接器也會為目錄中的既有品項建立映射。

## API v1

本機基址 `http://127.0.0.1:5182/api/v1`。瀏覽器 POST 必須帶相符的 Origin。規格可從 `/api/v1/openapi.json` 取得。舊路徑保留相容，但新整合使用 v1。

| 方法與路徑 | 用途 |
|---|---|
| GET /health | 服務及版本 |
| GET /status、/module | 資料集、工作進度、模型、訓練就緒狀態 |
| POST /classes、/prepare、/save | 新增品項、圖片預處理、儲存人工標註 |
| GET /sample/{id} | 已儲存圖片及人工標註 |
| POST /predict | 輸入 image（圖片 data URL）、model、confidence；輸出 objects、counts、model、elapsedMs |
| POST /train | mode=train 或 evaluate；model、epochs、device、displayName；單張另帶 practiceOnly=true、practiceSample |
| POST /stop | 停止正在執行的工作 |
| GET /catalog、POST /catalog | 讀寫標籤與品項 ID 映射 |
| POST /activate | 選擇已評估正式模型或通用模型；body: model |
| POST /models/rename | body: model、name |
| POST /export、GET /download/{id} | 匯出 YOLO 資料集快照 |

`objects` 格式：`[{"itemId":"品項ID或null","label":"瓶裝水","bbox":[0.1,0.2,0.4,0.8],"confidence":0.9}]`。bbox 為左、上、右、下，依圖片寬高正規化至 0–1；counts 依 label 統計。信心值不是實測準確率。

主系統另外提供 `/api/v1/recognize`、`/api/v1/feedback` 等轉接器 API。正式部署要使用既有 `deploy` 配置與 Supabase 認證，不能將本機 `run.py` 當公開服務。前端 `VITE_RECOGNITION_API_URL` 指向同源代理 `/vision-api`；程式自行加 `/api/v1`，不要在設定中重複加入。

## Linux 獨立測試與設定

```sh
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python run.py
```

服務只綁定 127.0.0.1。正式 Linux 整合部署請讀專案 `deploy/部署與操作說明.md`，必須一起帶上 `modules/vision`。

| 環境變數 | 預設／用途 |
|---|---|
| VISION_PORT | 5182 |
| VISION_DATA_DIR | 本資料夾 data；資料集、訓練輸出、啟用版本 |
| VISION_MODEL_DIR | 本資料夾 models；預訓練權重 |
| YOLO_INFERENCE_DEVICE | cpu；有相容 GPU 環境才改 0 |

備份時先停止訓練與服務，備份整個資料目錄與權重目錄；不要只備份 best.pt，類別、標註、工作設定也需要保存。獨立複製後若需攜帶既有專屬模型，建議保留原路徑或重新評估：舊版歷史評估僅記錄權重絕對路徑，搬移後可能需要再次評估才能啟用；本版新增的評估會以固定模型 ID 對應，不受搬移路徑影響。

## 開發與測試

核心在 `vision_module/worker.py`、資料處理在 `dataset.py`、訓練子程序在 `train.py`，版本化 API 與模型管理在 `api.py`，介面在 `ui/workbench.html`、`ui/editor.html`。舊 lab 的 yolo_worker/yolo_data/yolo_train 僅為相容轉接入口。

在此資料夾執行 `python -m unittest discover -s tests -v`。主系統轉接器的授權、混合辨識及回饋測試仍位於 `ai-recognition-lab/test_vision_service.py`；需要另行執行。離線測試以假回應驗證 Supabase/OpenAI，不代表真實部署連線已驗證。
