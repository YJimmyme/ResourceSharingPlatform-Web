"""Versioned transport and UI, with no host-system dependency."""
import json,os
from flask import request,jsonify,Response,g
from .dataset import read_json,write_json,now

def add_versioned_routes(app):
    for rule in list(app.url_map.iter_rules()):
        if rule.rule.startswith('/api/') or rule.rule in ['/','/workbench','/editor','/static/<path:filename>']:continue
        endpoint='v1_'+rule.endpoint
        if endpoint not in app.view_functions:
            app.add_url_rule('/api/v1'+rule.rule,endpoint,app.view_functions[rule.endpoint],methods=list(rule.methods-{'HEAD','OPTIONS'}))

def register(w):
    app=w.app
    def matches_model(config,model_id):
        return config.get('modelId')==model_id if config.get('modelId') else config.get('model')==str(w.model_path(model_id))
    @app.after_request
    def headers(response):
        response.headers['Cache-Control']='no-store'
        response.headers['X-Vision-API-Version']='1.0'
        return response
    def html(name):
        content=(w.ROOT/'ui'/name).read_text(encoding='utf-8')
        context='window.VISION_PRODUCTION='+json.dumps(os.environ.get('VISION_PRODUCTION')=='1')+';'
        return Response(content.replace('/*MODULE_CONTEXT*/',context),mimetype='text/html')
    @app.get('/')
    @app.get('/workbench')
    def module_workbench():return html('workbench.html')
    @app.get('/editor')
    def module_editor():return html('editor.html')
    @app.get('/health')
    def module_health():return jsonify(status='ok',service='vision-module',apiVersion='1.0')
    @app.get('/openapi.json')
    def contract():return jsonify(read_json(w.ROOT/'openapi.json'))
    @app.get('/module')
    def module_info():
        with w.lock:
            records=w.ds.records();train=[r for r in records if r['split']=='train' and r['boxes']];val=[r for r in records if r['split']=='val' and r['boxes']]
            learned={b['label'] for r in train for b in r['boxes']}
            missing=sorted({b['label'] for r in records if r['split']!='train' for b in r['boxes']}-learned)
            reasons=[]
            if not train:reasons.append('先在照片標註頁保存至少一張有框的訓練照片')
            if not val:reasons.append('一般建模還需要一張不同照片作為驗證集；目前可使用單張練習')
            if missing:reasons.append('這些驗證／測試品項缺少訓練樣本：'+'、'.join(missing))
            renamed=read_json(w.DATA/'model-names.json',{});models=[]
            for m in w.available_models():
                config=read_json(w.DATA/'runs'/m['id']/'config.json',{})
                evaluated=any(read_json(p,{}).get('status')=='completed' and read_json(p,{}).get('mode')=='evaluate' and matches_model(read_json(p.parent/'config.json',{}),m['id']) for p in (w.DATA/'runs').glob('*/state.json'))
                models.append({**m,'name':renamed.get(m['id']) or config.get('displayName') or m['label'],'practiceOnly':config.get('practiceOnly',False),'created':config.get('created'),'evaluated':evaluated,'canActivate':m['id']=='pretrained' or (evaluated and not config.get('practiceOnly',False))})
            jobs=[]
            for p in sorted((w.DATA/'runs').glob('*/state.json'),key=lambda p:p.stat().st_mtime,reverse=True):
                jobs.append({'id':p.parent.name,**read_json(p),'name':read_json(p.parent/'config.json',{}).get('displayName','')})
            return jsonify(apiVersion='1.0',production=os.environ.get('VISION_PRODUCTION')=='1',models=models,jobs=jobs,readiness={'canTrain':not reasons,'canPractice':bool(train),'canEvaluate':any(r['split']=='test' for r in records),'reasons':reasons},activeModel=read_json(w.DATA/'deployment.json',{'model':'pretrained'})['model'])
    @app.route('/catalog',methods=['GET','POST'])
    def catalog():
        with w.lock:
            if request.method=='POST':
                rows=(request.json or {}).get('mappings');mapping=read_json(w.DATA/'catalog-mapping.json',{})
                if not isinstance(rows,list):raise ValueError('請提供 mappings 陣列')
                for r in rows:
                    if not isinstance(r,dict) or r.get('label') not in w.ds.classes():raise ValueError('先新增標註品項')
                    item=r.get('itemId')
                    if item is not None and (not isinstance(item,str) or not item.strip() or len(item)>128):raise ValueError('itemId 必須是1至128字元字串或null')
                    mapping[r['label']]=item
                write_json(w.DATA/'catalog-mapping.json',mapping)
            mapping=read_json(w.DATA/'catalog-mapping.json',{})
            return jsonify(apiVersion='1.0',items=[{'classId':i,'label':name,'itemId':mapping.get(name)} for i,name in enumerate(w.ds.classes())])
    @app.post('/models/rename')
    def rename():
        b=request.json or {};id=b.get('model');w.model_path(id)
        name=str(b.get('name','')).strip()
        if not name or len(name)>60:raise ValueError('模型名稱需為1至60字')
        if id=='pretrained':raise ValueError('通用模型名稱固定')
        with w.lock:
            names=read_json(w.DATA/'model-names.json',{});names[id]=name;write_json(w.DATA/'model-names.json',names)
        return jsonify(success=True)
    @app.post('/activate')
    def activate():
        id=(request.json or {}).get('model');path=w.model_path(id)
        with w.lock:
            if id!='pretrained':
                config=read_json(w.DATA/'runs'/id/'config.json',{})
                if config.get('practiceOnly'):raise ValueError('單張練習模型不能發布，請以一般模式及獨立驗證資料重新訓練')
                state=read_json(w.DATA/'runs'/id/'state.json',{})
                if state.get('status')!='completed' or state.get('mode')!='train':raise ValueError('僅可啟用完成訓練的模型')
                evaluated=any(matches_model(read_json(p.parent/'config.json',{}),id) and read_json(p,{}).get('status')=='completed' and read_json(p,{}).get('mode')=='evaluate' for p in (w.DATA/'runs').glob('*/state.json'))
                if not evaluated:raise ValueError('請先完成此模型的保留集評估，再啟用')
            deployment=w.DATA/'deployment.json';old=read_json(deployment,{'model':'pretrained','history':[]})
            write_json(deployment,{'model':id,'updated':now(),'operator':getattr(g,'actor_id','local'),'history':old.get('history',[])+[{'model':old['model'],'changed':now()}]})
        return jsonify(success=True,model=id)
