import os,sys,json,threading,subprocess,uuid,io,base64,time
from pathlib import Path
from collections import Counter
from flask import Flask,request,jsonify,send_file
from .dataset import Dataset,read_json,write_json,now

ROOT=Path(__file__).resolve().parent
DATA=Path(os.environ.get('VISION_DATA_DIR',os.environ.get('YOLO_LAB_DATA',ROOT.parent/'data'))).resolve()
ds=Dataset(DATA);app=Flask(__name__);app.config['MAX_CONTENT_LENGTH']=64*1024*1024
lock=threading.RLock();infer_lock=threading.Lock();models={};active=None
PRETRAINED=Path(os.environ.get('VISION_MODEL_DIR',ROOT.parent/'models'))/'yolo11n.pt'
PRETRAINED.parent.mkdir(parents=True,exist_ok=True)
# Recovery runs only after acquiring the data lock, never during import.
def recover_jobs():
    for previous in (DATA/'runs').glob('*/state.json'):
        state=read_json(previous,{})
        if state.get('status') in ['starting','running','finishing']:
            write_json(previous,{**state,'status':'interrupted','error':'服務曾重新啟動，請重新執行此工作'})

def available_models():
    result=[{'id':'pretrained','label':'YOLO11n 通用預訓練（非專屬品項）'}]
    for p in sorted((DATA/'runs').glob('*/train/weights/best.pt')):
        if read_json(p.parents[2]/'state.json',{}).get('status')!='completed':continue
        result.append({'id':p.parents[2].name,'label':('練習模型（無獨立驗證） ' if read_json(p.parents[2]/'config.json',{}).get('practiceOnly') else '專屬模型 ')+p.parents[2].name})
    return result
def model_path(id):
    if id=='pretrained':return PRETRAINED
    if id not in [m['id'] for m in available_models()]:raise ValueError('請選擇已訓練的模型')
    return DATA/'runs'/id/'train'/'weights'/'best.pt'
def job_state():
    global active
    if not active:return None
    state=read_json(DATA/'runs'/active['id']/'state.json',{'status':'starting'})
    if active['process'].poll() is None and state['status']=='completed':state['status']='finishing'
    if active['process'].poll() is not None and state['status'] in ['starting','running']:
        state['status']='failed';state['error']='子程序結束，請查看執行紀錄';write_json(DATA/'runs'/active['id']/'state.json',state)
    state['id']=active['id']
    log=DATA/'runs'/active['id']/'console.log'
    state['log']=log.read_text(encoding='utf-8',errors='replace')[-7000:] if log.exists() else ''
    return state

@app.before_request
def guard():
    if os.environ.get('VISION_PRODUCTION')=='1':return
    if request.host.split(':')[0] not in ['127.0.0.1','localhost']:return jsonify(error='本機模式只接受本機網址'),403
    if request.method=='POST' and request.headers.get('Origin') not in ['http://127.0.0.1:'+os.environ.get('AI_LAB_PORT','5180'),'http://127.0.0.1:'+os.environ.get('VISION_PORT','5182')]:return jsonify(error='請從本機標註頁操作'),403
@app.errorhandler(Exception)
def error(e):return jsonify(error=str(e)),400
@app.get('/status')
def status():
    with lock:
        rows=ds.records();jobs=[{'id':p.parent.name,**read_json(p)} for p in (DATA/'runs').glob('*/state.json')];return jsonify(classes=ds.classes(),models=available_models(),samples=[{k:v for k,v in r.items() if k!='boxes'}|{'count':len(r['boxes'])} for r in rows],job=job_state(),jobs=jobs,deployment=read_json(DATA/'deployment.json',{'model':'pretrained'}),storage=str(DATA))
@app.post('/classes')
def add_class():
    with lock:return jsonify(classes=ds.add_class(request.json.get('name','')))
@app.post('/prepare')
def prepare():
    im,raw,id=ds.decode(request.json.get('image'));return jsonify(image='data:image/png;base64,'+base64.b64encode(raw).decode(),width=im.width,height=im.height,id=id)
@app.post('/save')
def save():
    with lock:return jsonify(record=ds.save(request.json))
@app.get('/sample/<id>')
def sample(id):
    with lock:
        r=ds.record(id);return jsonify(record=r,image='data:image/png;base64,'+base64.b64encode((DATA/'images'/f'{id}.png').read_bytes()).decode())
@app.post('/export')
def export():
    with lock:id,path=ds.export()
    return jsonify(id=id,url='/yolo-api/download/'+id)
@app.get('/download/<id>')
def download(id):
    if len(id)!=32 or any(c not in '0123456789abcdef' for c in id):raise ValueError('無效匯出ID')
    return send_file(DATA/'exports'/f'{id}.zip',as_attachment=True,download_name=f'yolo-dataset-{id}.zip')
@app.post('/predict')
def predict():
    b=request.json
    with lock:
        if active and active['process'].poll() is None:raise ValueError('訓練／評估中，請完成或停止後再辨識')
    selected=b.get('model') or read_json(DATA/'deployment.json',{'model':'pretrained'})['model']
    path=model_path(selected);im,raw,id=ds.decode(b.get('image'))
    conf=float(b.get('confidence',.25))
    if not .01<=conf<=.95:raise ValueError('信心門檻需介於0.01與0.95')
    start=time.time();boxes=infer_image(im,selected,conf)
    return jsonify(boxes=boxes,counts=dict(Counter(x['label'] for x in boxes)),elapsedMs=round((time.time()-start)*1000),apiVersion='1.0',model=selected,objects=object_contract(boxes),image='data:image/png;base64,'+base64.b64encode(raw).decode())
@app.post('/train')
def train():
    global active
    with lock:
        if active and active['process'].poll() is None:raise ValueError('已有執行中的工作')
        b=request.json;mode=b.get('mode','train');path=model_path(b.get('model','pretrained'))
        if mode not in ['train','evaluate']:raise ValueError('未知工作')
        epochs=int(b.get('epochs',30))
        if not 1<=epochs<=300:raise ValueError('輪數需介於1至300')
        if mode=='evaluate' and not any(r['split']=='test' for r in ds.records()):raise ValueError('先保存保留測試集照片')
        practice=b.get('practiceOnly') is True
        if practice and mode!='train':raise ValueError('單張練習不能作為保留集評估')
        practice_id=b.get('practiceSample') if practice else None
        if practice and not practice_id:raise ValueError('請選擇單張練習照片')
        snapshot,directory=ds.export(require_training=mode=='train',practice_id=practice_id)
        id=uuid.uuid4().hex[:12];run=DATA/'runs'/id;run.mkdir()
        display_name=str(b.get('displayName','')).strip()[:60]
        config={'displayName':display_name,'practiceOnly':practice,'practiceSample':practice_id,'mode':mode,'modelId':b.get('model','pretrained'),'model':str(path),'dataset':str(directory),'epochs':epochs,'device':b.get('device','cpu'),'confidence':.15,'created':now()}
        if config['device'] not in ['cpu','0']:raise ValueError('裝置僅支援CPU或GPU 0')
        write_json(run/'config.json',config);write_json(run/'state.json',{'status':'starting','snapshot':snapshot,'mode':mode,'practiceOnly':practice})
        log=open(run/'console.log','w',encoding='utf-8')
        process=subprocess.Popen([sys.executable,str(ROOT/'train.py'),str(run)],stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));log.close();active={'id':id,'process':process}
        return jsonify(id=id)
@app.post('/stop')
def stop():
    with lock:
        if active and active['process'].poll() is None:
            active['process'].terminate();active['process'].wait(timeout=15);write_json(DATA/'runs'/active['id']/'state.json',{'status':'stopped'})
        return jsonify(success=True)

def infer_image(image,model_id='pretrained',confidence=.25):
    path=model_path(model_id)
    with infer_lock:
        from ultralytics import YOLO
        if str(path) not in models:models[str(path)]=YOLO(str(path))
        result=models[str(path)].predict(image,conf=confidence,imgsz=640,device=os.environ.get('YOLO_INFERENCE_DEVICE','cpu'),verbose=False)[0]
        return [{'label':result.names[int(cls)],'box':xy,'confidence':float(c)} for xy,cls,c in zip(result.boxes.xyxyn.tolist(),result.boxes.cls.tolist(),result.boxes.conf.tolist())]

def object_contract(boxes):
    mapping=read_json(DATA/'catalog-mapping.json',{})
    return [{'itemId':mapping.get(b['label']),'label':b['label'],'bbox':b['box'],'confidence':b['confidence']} for b in boxes]

from . import api
api.register(sys.modules[__name__])
