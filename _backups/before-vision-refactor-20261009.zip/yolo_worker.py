"""Compatibility entrypoint plus the host-system authentication adapter."""
import os,sys
import _vision_bridge
from vision_module import worker as core
if os.environ.get('VISION_PRODUCTION')=='1':
    import vision_service
    vision_service.register(core)
core.api.add_versioned_routes(core.app)
app=core.app
if __name__=='__main__' or os.environ.get('VISION_LOCK_DATA')=='1':
    from vision_module.locking import acquire
    acquire(core.DATA)
    core.recover_jobs()
if __name__=='__main__':app.run(host='127.0.0.1',port=int(os.environ.get('YOLO_LAB_PORT',5181)),threaded=True,use_reloader=False)
else:sys.modules[__name__]=core
