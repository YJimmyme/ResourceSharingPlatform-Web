"""Standalone localhost server. Run without the host application or Supabase."""
import os
if os.environ.get('VISION_PRODUCTION')=='1':raise SystemExit('Use the host authentication adapter for production deployment.')
from vision_module import worker
from vision_module.locking import acquire
try:
    acquire(worker.DATA)
except RuntimeError as exc:
    raise SystemExit(str(exc)) from None
worker.recover_jobs()
worker.api.add_versioned_routes(worker.app)
port=int(os.environ.get('VISION_PORT',5182))
print(f'YOLO 模組：http://127.0.0.1:{port}/workbench',flush=True)
worker.app.run(host='127.0.0.1',port=port,threaded=True,use_reloader=False)
