"""Opt-in real CPU smoke test, isolated copied module; never uses user images.
Run: python tests/smoke_standalone.py --weights /path/to/models
"""
import argparse,base64,io,json,os,shutil,subprocess,sys,tempfile,time
from pathlib import Path
import requests
from PIL import Image,ImageDraw

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--weights',required=True);args=parser.parse_args()
    source=Path(__file__).resolve().parents[1]
    with tempfile.TemporaryDirectory(prefix='vision-smoke-') as temp:
        root=Path(temp)
        shutil.copytree(source/'vision_module',root/'vision_module',ignore=shutil.ignore_patterns('__pycache__'))
        shutil.copy(source/'run.py',root/'run.py')
        env=os.environ.copy();env.pop('VISION_PRODUCTION',None)
        env.update(VISION_DATA_DIR=str(root/'data'),VISION_MODEL_DIR=str(Path(args.weights).resolve()),VISION_PORT='5192',PYTHONIOENCODING='utf-8')
        base='http://127.0.0.1:5192/api/v1';headers={'Origin':'http://127.0.0.1:5192'}
        def call(route,body=None):
            r=requests.get(base+route,timeout=60) if body is None else requests.post(base+route,json=body,headers=headers,timeout=120)
            r.raise_for_status();return r.json()
        with open(root/'server.log','w',encoding='utf-8') as log:
            process=subprocess.Popen([sys.executable,'run.py'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            try:
                for _ in range(50):
                    if process.poll() is not None:raise RuntimeError((root/'server.log').read_text(encoding='utf-8'))
                    try:
                        call('/health');break
                    except requests.ConnectionError:time.sleep(.2)
                assert Path(call('/status')['storage'])==(root/'data').resolve(), 'Port belongs to another service'
                call('/classes',{'name':'測試方塊'})
                picture=Image.new('RGB',(192,192),'white');ImageDraw.Draw(picture).rectangle((45,45,145,145),fill='blue')
                stream=io.BytesIO();picture.save(stream,format='PNG');image='data:image/png;base64,'+base64.b64encode(stream.getvalue()).decode()
                record=call('/save',{'image':image,'filename':'synthetic-test.png','boxes':[{'label':'測試方塊','box':[45/192,45/192,145/192,145/192]}],'split':'train','reviewed':True})['record']
                job=call('/train',{'mode':'train','model':'pretrained','epochs':1,'device':'cpu','practiceOnly':True,'practiceSample':record['id'],'displayName':'隔離流程測試'})['id']
                deadline=time.monotonic()+300
                while time.monotonic()<deadline:
                    state=call('/status')['job']
                    if state['status'] in ['completed','failed','stopped']:break
                    time.sleep(1)
                assert state['status']=='completed',state
                prediction=call('/predict',{'image':image,'model':job})
                assert prediction['model']==job and prediction['apiVersion']=='1.0'
                assert call('/sample/'+record['id'])['record']['revision']==record['revision']
                rejection=requests.post(base+'/activate',json={'model':job},headers=headers,timeout=10)
                assert rejection.status_code==400
                report={'standaloneCopy':True,'training':state['status'],'practiceOnly':state['practiceOnly'],'predictionBoxes':len(prediction['objects']),'annotationPreserved':True,'practiceActivationRejected':True}
                print(json.dumps(report,ensure_ascii=False),flush=True)
            finally:
                try:requests.post(base+'/stop',json={},headers=headers,timeout=20)
                except requests.RequestException:pass
                process.terminate();process.wait(timeout=20)

if __name__=='__main__':main()
