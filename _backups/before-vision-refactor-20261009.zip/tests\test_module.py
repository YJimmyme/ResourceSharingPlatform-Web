import os,sys,tempfile,unittest,io,base64,types,subprocess
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
tmp=tempfile.TemporaryDirectory()
os.environ.pop('VISION_PRODUCTION',None)
os.environ['VISION_DATA_DIR']=tmp.name
from vision_module import worker as w
from vision_module.dataset import Dataset,read_json,write_json
w.api.add_versioned_routes(w.app)
class ModuleTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        w.DATA=Path(self.temp.name);w.ds=Dataset(w.DATA);w.active=None;w.models.clear()
        self.client=w.app.test_client();self.headers={'Origin':'http://127.0.0.1:5182'}
        b=io.BytesIO();from PIL import Image
        Image.new('RGB',(80,80),'white').save(b,format='PNG');self.image='data:image/png;base64,'+base64.b64encode(b.getvalue()).decode()
    def post(self,path,body):return self.client.post('/api/v1'+path,json=body,headers=self.headers)
    def sample(self):
        w.ds.add_class('瓶裝水');return w.ds.save({'image':self.image,'reviewed':True,'split':'train','boxes':[{'label':'瓶裝水','box':[.1,.1,.8,.8]}]})
    def test_independent_ui_and_contract(self):
        self.assertEqual(self.client.get('/workbench').status_code,200)
        self.assertIn('準備正確答案',self.client.get('/workbench').get_data(as_text=True))
        self.assertIn('window.VISION_PRODUCTION=false',self.client.get('/editor').get_data(as_text=True))
        spec=self.client.get('/api/v1/openapi.json').json;self.assertEqual(spec['openapi'],'3.1.0')
        self.assertEqual(self.client.get('/api/v1/health').json['service'],'vision-module')
    def test_local_write_origin_and_host(self):
        self.assertEqual(self.client.post('/api/v1/classes',json={'name':'水'}).status_code,403)
        self.assertEqual(self.client.get('/api/v1/status',headers={'Host':'attacker.invalid'}).status_code,403)
        self.assertEqual(self.post('/classes',{'name':'水'}).status_code,200)
    def test_readiness_and_persistence(self):
        self.assertFalse(self.client.get('/api/v1/module').json['readiness']['canPractice'])
        self.sample();r=self.client.get('/api/v1/module').json['readiness'];self.assertTrue(r['canPractice']);self.assertFalse(r['canTrain']);self.assertFalse(r['canEvaluate'])
        self.assertEqual(len(Dataset(w.DATA).records()),1)
    def test_mapping_and_prediction_contract(self):
        self.sample();self.assertEqual(self.post('/catalog',{'mappings':[{'label':'瓶裝水','itemId':'item-42'}]}).status_code,200)
        with patch.object(w,'infer_image',return_value=[{'label':'瓶裝水','box':[.1,.1,.8,.8],'confidence':.8}]):
            r=self.post('/predict',{'image':self.image})
            self.assertEqual(r.status_code,200,r.json);self.assertEqual(r.json['objects'][0]['itemId'],'item-42');self.assertEqual(r.json['counts'],{'瓶裝水':1});self.assertEqual(r.json['apiVersion'],'1.0')
        self.assertEqual(self.post('/catalog',{'mappings':[{'label':'不存在','itemId':'x'}]}).status_code,400)
    def test_practice_model_not_activatable_and_rename(self):
        run=w.DATA/'runs/model1';weights=run/'train/weights/best.pt';weights.parent.mkdir(parents=True);weights.touch()
        write_json(run/'config.json',{'practiceOnly':True,'displayName':'第一版'});write_json(run/'state.json',{'status':'completed','mode':'train'})
        models=self.client.get('/api/v1/module').json['models'];self.assertFalse(models[1]['canActivate'])
        self.assertEqual(self.post('/activate',{'model':'model1'}).status_code,400)
        self.assertEqual(self.post('/models/rename',{'model':'model1','name':'飲品練習'}).status_code,200)
        self.assertEqual(self.client.get('/api/v1/module').json['models'][1]['name'],'飲品練習')
    def test_active_model_default_and_shared_data_lock(self):
        run=w.DATA/'runs/normal';weights=run/'train/weights/best.pt';weights.parent.mkdir(parents=True);weights.touch()
        write_json(run/'state.json',{'status':'completed','mode':'train'});write_json(run/'config.json',{})
        ev=w.DATA/'runs/eval';write_json(ev/'state.json',{'status':'completed','mode':'evaluate'});write_json(ev/'config.json',{'modelId':'normal','model':'/previous-computer/runs/normal/train/weights/best.pt'})
        self.assertEqual(self.post('/activate',{'model':'normal'}).status_code,200)
        with patch.object(w,'infer_image',return_value=[]) as predict:
            self.assertEqual(self.post('/predict',{'image':self.image}).json['model'],'normal')
            self.assertEqual(predict.call_args.args[1],'normal')
        # Independent process must not acquire a dataset owned by this process.
        from vision_module import locking
        locking.acquire(w.DATA)
        code='from pathlib import Path; from vision_module.locking import acquire; acquire(Path('+repr(str(w.DATA))+'))'
        r=subprocess.run([sys.executable,'-c',code],cwd=Path(__file__).resolve().parents[1],capture_output=True)
        self.assertNotEqual(r.returncode,0)
        locking._handle.close()
if __name__=='__main__':unittest.main()
